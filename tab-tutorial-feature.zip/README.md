# بستهٔ آموزش گرافی تب‌ها

این بسته یک دکمهٔ «آموزش کار با این تب» با راهنمای گرافیِ مرحله‌به‌مرحله اضافه می‌کند.
محتوا برای فارسی و انگلیسی آماده است؛ در localeهای دیگر فعلاً متن انگلیسی نمایش داده می‌شود.

## نصب در ریشهٔ پروژه

1. ZIP را در ریشهٔ پروژه استخراج کنید؛ سه فایل جدید با مسیرهای `client/src/...` اضافه می‌شوند.
2. از ریشهٔ پروژه، تغییر فایل‌های موجود را اعمال کنید:

   ```bash
   git apply --unidiff-zero integration.patch
   ```

3. سپس تغییرها را بررسی و build/test پروژه را اجرا کنید.

اگر نسخهٔ فایل‌های مقصد با نسخهٔ پایهٔ این بسته فرق دارد و patch اعمال نشد، تغییرات `integration.patch` را با همان مسیرها به‌صورت دستی ادغام کنید.

## فایل‌ها

- `client/src/components/tab-tutorial.tsx` — دکمه و پنجرهٔ راهنمای گرافی.
- `client/src/lib/tab-tutorials.ts` — مسیرها و محتوای دوزبانهٔ ۲۰ راهنما.
- `client/src/lib/tab-tutorials.test.ts` — آزمون نگاشت مسیرها و کامل‌بودن محتوا.
- `integration.patch` — اتصال به `PageHeader`، تب‌های داخلی Keys و نوار کناری Playground.

`PageHeader` آموزش route-aware را برای مدل‌های گفتگو/Fusion/Embeddings/تصویر/ویدیو/صوت، جزئیات مدل، Keys، Agents، ForgePilot، Analytics، Logs و Premium نشان می‌دهد. تب‌های داخلی Keys شناسهٔ راهنمای مستقل دارند. دکمهٔ Playground حتی در حالت جمع‌شدهٔ نوار کناری هم در دسترس است.

## یادداشت وضعیت build در این clone

در checkoutی که این بسته از آن ساخته شده، چند فایل پایه از قبل دارای conflict markerهای merge هستند (از جمله `package.json` ریشه و `client/src/App.tsx`). به همین دلیل build و Vitest کامل در همین clone به خطا می‌خورند؛ قبل از اجرای آن‌ها باید conflictهای قبلی پروژه حل شوند. فایل راهنما و اتصال‌های `PageHeader` و Playground با TypeScript ایزوله بررسی شده‌اند؛ `KeysPage` و build کامل به‌دلیل conflict markerهای قبلی قابل کامپایل نیستند.
